<?php
/**
 *@package prs-menu
 */
settings_errors();
echo '<form action="options.php" method="post">';

	settings_fields( 'prs-menu-setting-dynamics' );

	do_settings_sections( 'prs_wp_nav_menu' );

	submit_button();

echo '</form>';