<?php
/**
 *@package prs-menu
 */
/*
Plugin Name: Prs Custom Nav Menu
Plugin URI: http://localhost:8000/
Description: WordPress custom menu
Version: 1.0
Author: Pravin Shrikhande
Author URI: https://github.com/pravinshrikhande
Licence: GPL V2
Text Domain: prsmenu
*/
defined('ABSPATH') or die('Hey U are silly user');
if(file_exists(dirname(__FILE__).'/vendor/autoload.php'))
{
	require_once dirname(__FILE__).'/vendor/autoload.php';
}

use Inc\Base\Activate;
use Inc\Base\Deactivate;

function activate_plugin_data()
{
	Activate::activate();
}

 function deactivate_plugin_data()
 {
 	Deactivate::deactivate();
 }


register_activation_hook( __FILE__, 'activate_plugin_data' );
register_deactivation_hook( __FILE__, 'deactivate_plugin_data' );

if(class_exists("Inc\\Init"))
{
	"Inc\Init"::register_services();
}

add_action( 'wp_head', 'prs_menu_style_dynamic', 10 );
add_action( 'wp_head', 'prs_menu_nav_template', 10 );

function prs_menu_style_dynamic()
{
	?>
	<style type="text/css">
   			<?php include_once(dirname(__FILE__) . '/Templates/prs_menu_style_dynamic.php'); ?>
    </style>
	<?php
}
function prs_menu_nav_template()
{
	include_once(dirname(__FILE__) . '/Templates/prs-menu-nav-template.php');
	$theme_type = get_option( 'theme_type' );
	if($theme_type == 'light') {
		echo '<script>jQuery("#switch").addClass("switched");</script>';
		add_filter('body_class', 'prs_menu_body_class');
	}
}

function prs_menu_body_class($classes) {
    $classes[] = 'light';
    return $classes;
}