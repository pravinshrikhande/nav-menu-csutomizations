<?php
/**
 *@package prs-menu
 */
namespace Inc;
/**
 *  Call All The Services in the Plugin
 */
final class Init
{

	public static function get_services()
	{
		return [
			Pages\Admin_Pages::class,
			Base\Enqueue::class,
			Base\SettingsLinks::class,
			Base\RegisterSettings::class
		];
	}

	public static function register_services()
	{
		foreach (self::get_services() as $class) {
			$services = self::instatiate($class);
			if(method_exists($services, 'register'))
			{
				$services->register();
			}
		}
	}

	public static function instatiate($class)
	{
		$services =  new $class;

		return $services;
	}
}

