<?php
/**
 *@package prs-menu
 */
namespace Inc\Base;
/**
 * Deactivate plugin
 */
class Deactivate
{
	
	public static function deactivate()
	{
		flush_rewrite_rules();
	}
}