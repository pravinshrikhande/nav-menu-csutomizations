<?php
/**
 *@package prs-menu
 */
namespace Inc\Base;
/**
 * Activate plugin
 */
class Activate
{
	
	public static function activate()
	{
		flush_rewrite_rules();
	}
}