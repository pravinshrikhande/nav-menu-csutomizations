<?php 
/**
 * @package  prs-menu
 */
namespace Inc\Base;

use Inc\Base\BaseController;

class RegisterSettings extends BaseController
{
	public function register()
	{
		add_action( 'admin_init', array($this, 'prsmenu_settings_fields') );
	}

	//Setting page Star Reviews
	public function prsmenu_settings_fields()
	{
		//register settings
		register_setting( 'prs-menu-setting-dynamics', 'theme_type');
		register_setting( 'prs-menu-setting-dynamics', 'menu_background');
		register_setting( 'prs-menu-setting-dynamics', 'prs_menu_font_color');
		register_setting( 'prs-menu-setting-dynamics', 'prs_menu_font_size');
		register_setting( 'prs-menu-setting-dynamics', 'prs_menu_position');

		//register section area
		add_settings_section( 'prs-menu-setting-section', 'WP Menu Settings', array($this, 'prsmenu_setting_section'), 'prs_wp_nav_menu' );

		//register field area
		add_settings_field( 'prs-menu-setting-field-theme', 'Theme Type : ', array($this, 'prs_menu_theme_type'), 'prs_wp_nav_menu', 'prs-menu-setting-section');

		//register field area
		add_settings_field( 'prs-menu-setting-field', 'Menu Background : ', array($this, 'prs_menu_background'), 'prs_wp_nav_menu', 'prs-menu-setting-section');

		add_settings_field( 'prs-menu-setting-field-hover', 'Color & Size : ', array($this, 'prs_menu_text_color'), 'prs_wp_nav_menu', 'prs-menu-setting-section');

		add_settings_field( 'prs-menu-setting-field-tc', 'Menu Position : ', array($this, 'prs_menu_nav_position'), 'prs_wp_nav_menu', 'prs-menu-setting-section');

	}

	public function prsmenu_setting_section()
	{
		//echo "<h2>Menu Settings</h2>";
	}

	public function prs_menu_theme_type()
	{
		$theme_type = get_option( 'theme_type' );
		$dark = '';
		$light = '';
		if($theme_type == 'dark')
		{
			$dark = 'checked=checked';
		}
		else
		{
			$light = 'checked=checked';
		}
		echo '<input type="radio" name="theme_type" '.$dark.' value="dark">Dark &nbsp; &nbsp;';
		echo '<input type="radio" name="theme_type" '.$light.' value="light"> Light';
	}

	public function prs_menu_background()
	{
		$menu_background = get_option( 'menu_background' );
		echo '<input type="text" name="menu_background" value="'.$menu_background.'"/>';
	}

	public function prs_menu_text_color()
	{
		$color = get_option( 'prs_menu_font_color' );
		$size  = get_option( 'prs_menu_font_size' );

			echo '<input type="text" name="prs_menu_font_color" value="'.$color.'"/>
			<input type="number" name="prs_menu_font_size" value="'.$size.'" min="5" max="25"/><br/>';
	}

	public function prs_menu_nav_position()
	{
		$menuposition = get_option( 'prs_menu_position' );
		$left = '';
		$right = '';
		if($menuposition == 'left')
		{
			$left = 'checked=checked';
		}
		else
		{
			$right = 'checked=checked';
		}
		echo '<input type="radio" name="prs_menu_position" '.$left.' value="left">Left &nbsp; &nbsp;';
		echo '<input type="radio" name="prs_menu_position" '.$right.' value="right"> Right';
	}
}