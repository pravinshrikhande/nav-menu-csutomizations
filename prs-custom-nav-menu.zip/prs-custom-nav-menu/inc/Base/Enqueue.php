<?php
/**
 *@package prs-menu
 */
namespace Inc\Base;
use Inc\Base\BaseController;
/**
 * All Css and JS in plugin
 */
class Enqueue extends BaseController
{
	
	public function register()
	{
		add_action( 'wp_enqueue_scripts', array($this, 'register_enqueue_data') );
	}

	public function register_enqueue_data()
	{
		//wp_enqueue_style( 'prs-nav-menu-css', plugin_dir_url( dirname( __FILE__, 2 ) ).'/inc/Templates/css/prs-nav-menu.css' );
		wp_enqueue_script( 'prs-nav-menu-js', plugin_dir_url( dirname( __FILE__, 2 ) ).'Templates/js/prs-nav-menu.js' , array('jquery'), '', true );
	}
}