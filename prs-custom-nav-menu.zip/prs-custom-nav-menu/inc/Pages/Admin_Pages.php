<?php
/**
 *@package prs-menu
 */
namespace Inc\Pages;
use Inc\Callbacks\AdminCallBacks;
use Inc\Base\BaseController;
/**
 * Admin Pages
 */
class Admin_Pages extends BaseController
{
	public $Callbacks;

	public function register()
	{
		$this->Callbacks = new AdminCallbacks;
		add_action( 'admin_menu', array($this, 'prs_admin_menu_pages') );
	}

	public function prs_admin_menu_pages()
	{
		add_menu_page( 'WP Menu', 'WP Menu', 'manage_options', 'prs_wp_nav_menu', array($this->Callbacks, 'prs_WP_Nav_Dashboard'), 'dashicons-menu-alt3', 110 );
	}
}