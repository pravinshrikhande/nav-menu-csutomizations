<?php 
/**
 * @package  prs-menu
 */
namespace Inc\Callbacks;

use Inc\Base\BaseController;

class AdminCallbacks extends BaseController
{
	public function prs_WP_Nav_Dashboard()
	{
		//echo $this->plugin_path.'/Templates/prs-wp-nav-menu.php';
		return require_once( "$this->plugin_path/Templates/prs-wp-nav-menu.php" );
	}
}